#include <stdio.h>
#define TAM_ARRAY 10

int main()
{
    int arrayA[TAM_ARRAY] = {33,2,65,4,98,6,87,8,12,10};
    int arrayB[TAM_ARRAY] = {31,12,61,1,11,111,17,120,12,10};
    int i;
    int Soma = 0;
    
    for(i = 0; i < TAM_ARRAY; i++){
        
        Soma = Soma + arrayA[i] + arrayB[i];
    }
    
    printf("O vetor resultante da soma destes vetores é: %d\n", Soma);

    return 0;
}
